package com.seu.grupo.produtividade.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.seu.grupo.produtividade.model.Dica;
import com.seu.grupo.produtividade.repository.DicaRepository;

import java.util.Date;
import java.util.List;

@Service
public class DicaService {

    @Autowired
    private DicaRepository dicaRepository;

    public Dica salvarDica(String titulo, String descricao, String autor, Date dataPublicacao) {
        Dica dica = new Dica(titulo, descricao, autor, dataPublicacao);
        return dicaRepository.save(dica);
    }

    public List<Dica> getAllDicas() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getAllDicas'");
    }

    // Outros métodos conforme necessário (buscar, atualizar, deletar)
}
