package com.seu.grupo.produtividade.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.seu.grupo.produtividade.model.Dica;
import com.seu.grupo.produtividade.service.DicaService;

import java.util.List;

@RestController
@RequestMapping("/dicas")
public class DicaController {

    @Autowired
    private DicaService dicaService;

    @GetMapping
    public List<Dica> getAllDicas() {
        return dicaService.getAllDicas();
    }

    @PostMapping
    public Dica createDica(@RequestBody Dica dica) {
        return dicaService.salvarDica(dica.getTitulo(), dica.getDescricao(), dica.getAutor(), dica.getDataPublicacao());
    }

    // Outros endpoints (PUT, DELETE) se necessário
}
