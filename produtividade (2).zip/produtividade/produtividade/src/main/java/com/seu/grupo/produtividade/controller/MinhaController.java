package com.seu.grupo.produtividade.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MinhaController {

    @GetMapping("/minha-rota")
    public String minhaRota() {
        return "Acessando minha rota!";
    }
}
