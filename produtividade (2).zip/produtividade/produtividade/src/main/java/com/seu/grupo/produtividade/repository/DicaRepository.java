
package com.seu.grupo.produtividade.repository;

import com.seu.grupo.produtividade.model.Dica;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DicaRepository extends JpaRepository<Dica, Long> {
    
}

