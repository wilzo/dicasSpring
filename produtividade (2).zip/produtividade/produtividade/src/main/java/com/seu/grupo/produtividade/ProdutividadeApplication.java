package com.seu.grupo.produtividade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdutividadeApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProdutividadeApplication.class, args);
    }
}
