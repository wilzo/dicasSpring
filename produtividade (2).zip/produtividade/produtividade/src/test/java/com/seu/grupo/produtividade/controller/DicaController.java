package com.seu.grupo.produtividade.controller;

import com.seu.grupo.produtividade.model.Dica;
import com.seu.grupo.produtividade.repository.DicaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/dicas")
public class DicaController {

    @Autowired
    private DicaRepository dicaRepository;

    @GetMapping
    public List<Dica> getAllDicas() {
        return dicaRepository.findAll();
    }

    @PostMapping
    public Dica createDica(@RequestBody Dica dica) {
        return dicaRepository.save(dica);
    }

    // Outros endpoints (PUT, DELETE) se necessário
}
